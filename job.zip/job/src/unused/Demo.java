package unused;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import database.SessionUtility;
import job.RequestJobs;

public class Demo 
{
	
	
	public static void main(String[] args) 
	{
		
		
		/*
		
				Session session1=SessionUtility.GetSessionConnection();
				Criteria cr = session1.createCriteria(ServiceRequester.class)
				  .setProjection(Projections.projectionList()
			      .add(Projections.property("rq_name"), "rq_name")
			      .add(Projections.property("rq_address"),"rq_address")
			      .add(Projections.property("rq_email"),"rq_email")
			      .add(Projections.property("rq_contact"),"rq_contact"))
			    .setResultTransformer(Transformers.aliasToBean(ServiceRequester.class));
				
				
				
				
	
		Criteria cr=session1.createCriteria(ServiceProvider.class,"ser");
		cr.createAlias("ser.jobs", "ad");
		cr.add(Restrictions.eq("ad.job_name","java developer"));	
		@SuppressWarnings("unchecked")
		List<ServiceProvider> ad=cr.list();
		Iterator<ServiceProvider> it=ad.iterator();
		System.out.println(ad);
		if(it.hasNext())
		{
			System.out.println("in loop:Specialization");
			System.out.println(it.next().getSp_username());
		}
				
				
				
	
				System.out.println("SQL statements executed....");
				  @SuppressWarnings("unchecked")
				List<ServiceRequester> list = cr.list();
				  Iterator<ServiceRequester> iter=list.iterator();
	
				System.out.println("The list starts");
				while(iter.hasNext())
				{
					System.out.println(iter.next().getRq_name());
					
				}
		
		
		
		
		
	}

	*/
		
		
		Session session1=(Session)SessionUtility.GetSessionConnection();
		
	
	//	String hql = "FROM job.Jobs where job_name = :jobname";
	//	String hql = "FROM job.RequestJobs where sp_username = :name";
		String hql = "FROM job.RequestJobs where rqobj = :rqobj";
		Query query = session1.createQuery(hql);
		query.setInteger("rqobj",1);
		@SuppressWarnings("unchecked")
		List<RequestJobs> results = query.list();
		System.out.println(results);
		Iterator<RequestJobs> it=results.iterator();
		System.out.println("List executed");
		while (it.hasNext())
		{
			System.out.println("Job Name"+it.next().getJob_name());
			
			//updating the applyrequest to reqid value
		}	
	}
}
