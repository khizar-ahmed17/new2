package controller;

import java.util.Iterator;

//This Method is used to retrieve the name of the Company who has posted for jobs

import java.util.List;

import javax.servlet.http.HttpSession;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import job.Jobs;
import job.ServiceProvider;
import database.SessionUtility;

@Controller
@RequestMapping("index")
public class SearchController
{
	
	@Autowired
	Jobs jobbean;
	
	public Jobs getJobbean() {
		return jobbean;
	}

	public void setJobbean(Jobs jobbean) {
		this.jobbean = jobbean;
	}

	@Autowired
	ServiceProvider providerbean;


	public ServiceProvider getProviderbean() {
		return providerbean;
	}

	public void setProviderbean(ServiceProvider providerbean) {
		this.providerbean = providerbean;
	}
	
	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView start(Jobs jobbean,HttpSession session)
	{
		ModelAndView md=new ModelAndView();
		md.addObject("jobbean",jobbean);
		
		String i=(String) session.getAttribute("username");
		
		System.out.println(i);
		if(i==null)
		{
		md.setViewName("index");
		}
		else
		{
			md.setViewName("inindex");
		}
		
		return md;
		
		
	}
	
	

	@RequestMapping(method=RequestMethod.POST)
	public ModelAndView movetoposition(Jobs jobbean,ServiceProvider providerbean,HttpSession session)
	{
			System.out.println("In Get method of Specialization");
			ModelAndView mdlv=new ModelAndView();
			String jobname=jobbean.getSearch();
			String uname = null;
			
			Session session1=(Session)SessionUtility.GetSessionConnection();
			
			Criteria cr1=session1.createCriteria(ServiceProvider.class,"ser");
			cr1.createAlias("ser.jobs", "ad");
			cr1.add(Restrictions.eq("ad.job_name",jobname));	
			@SuppressWarnings("unchecked")
			List<ServiceProvider> ad1=cr1.list();
			Iterator<ServiceProvider> itr=ad1.iterator();
			System.out.println(ad1);
			while(itr.hasNext())
			{
				System.out.println("in loop");
				uname=itr.next().getSp_username();
				
			}
			
			
			
			
			
			String hql = "FROM job.ServiceProvider where sp_username = :name";
			Query query = session1.createQuery(hql);
			query.setString("name",uname);
			
			

			
			
			@SuppressWarnings("unchecked")
			List<ServiceProvider> results = query.list();
			System.out.println(results);
			Iterator<ServiceProvider> it=results.iterator();
			
			if (it.hasNext())
			{
				System.out.println("Address:"+it.next().getSp_address());
				
				//updating the applyrequest to reqid value
			}
			mdlv.addObject("jobname", jobname);
			mdlv.setViewName("search");
			mdlv.addObject("search",results);
			return mdlv;
		
		}
	
//	@RequestMapping(method=RequestMethod.POST)
//	public ModelAndView nextposition(ServiceProvider providerbean)
//	{
//		ModelAndView md=new ModelAndView();
//		Session session1=(Session)SessionUtility.GetSessionConnection();
////		Criteria cr=session1.createCriteria(ServiceRequester.class,"ser");
////		cr.createAlias("ser.jobs", "ad");
////		cr.add(Restrictions.eq("ad.job_specialization","Java"));	
////		List<ServiceRequester> results=cr.list();
////		Iterator<ServiceRequester> iter=results.iterator();
////		if(iter.hasNext())
////		{
////			System.out.println(iter.next().getRq_name());
////		}
//		
//		Criteria cr = session1.createCriteria(ServiceProvider.class)
//			    .setProjection(Projections.projectionList()
//			      .add(Projections.property("sp_username"), "sp_username"))
//			    .setResultTransformer(Transformers.aliasToBean(ServiceProvider.class));
//
//			  List<ServiceProvider> ad = cr.list();
//			  Iterator<ServiceProvider> it=ad.iterator();
//		  while(it.hasNext())
//		  	{
//			  System.out.println(it.next().getSp_username());
//			 
//		  	}	
//		
//		md.addObject("allcompany",ad);
//		System.out.println("Object added Successfully");
//		md.addObject("providerbean",providerbean);
//		md.setViewName("requestallcompany");
//		return md;
//		
//	}
	
	
	
	
}
