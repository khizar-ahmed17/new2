package controller;

import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.hibernate.Criteria;
import org.hibernate.classic.Session;

import org.hibernate.criterion.Projections;
import org.hibernate.transform.Transformers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import job.Applied;
import database.SessionUtility;


@Controller
@RequestMapping("requestapplicant")
public class ApplicantController
{
	
	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView movetoposition(Applied bean,HttpSession session)
	{
			System.out.println("In Get method of Applicant Controller");
			ModelAndView md=new ModelAndView();
			Session session1=(Session)SessionUtility.GetSessionConnection();
			System.out.println("hi");
			Criteria cr = session1.createCriteria(Applied.class)
				    .setProjection(Projections.projectionList()
				      .add(Projections.property("applied"), "applied")
				      .add(Projections.property("jobname"),"jobname")
				      .add(Projections.property("requestername"),"requestername")
				      .add(Projections.property("cname"),"cname"))
				    .setResultTransformer(Transformers.aliasToBean(Applied.class));
			System.out.println("SQL statements executed....");
				  @SuppressWarnings("unchecked")
				List<Applied> list = cr.list();
				  Iterator<Applied> iter=list.iterator();
				  System.out.println(list);
				  if(iter.hasNext())
				  {
					  iter.next().getJobname();
				  }
				md.addObject("applicant",list);
				md.addObject("bean",bean);
				
			
				
			
				md.setViewName("applicant");
				
				return md;
				
		
		
		}


}
