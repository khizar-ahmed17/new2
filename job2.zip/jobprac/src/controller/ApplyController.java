package controller;


import java.util.Iterator;
import java.util.List;


import javax.servlet.http.HttpSession;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import job.Applied;
import job.Jobs;
import job.ServiceProvider;
import job.ServiceRequester;
import database.SessionUtility;


@Controller
@RequestMapping("requestapply")
public class ApplyController
{
	@Autowired
	ServiceProvider providerbean;
	
	public ServiceProvider getProviderbean() {
		return providerbean;
	}

	public void setProviderbean(ServiceProvider providerbean) {
		this.providerbean = providerbean;
	}

	@Autowired
	Jobs jobbean;
	
	public Jobs getJobbean() {
		return jobbean;
	}

	public void setJobbean(Jobs jobbean) {
		this.jobbean = jobbean;
	}

	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView movetoposition(Applied a,Jobs jobbean,ServiceRequester requestbean,HttpSession session)
	{
	String i=(String) session.getAttribute("username");
		
		System.out.println(i);
		if(i==null)
		{
			ServiceProvider userbean=new ServiceProvider();
			ModelAndView mdlvie=new ModelAndView();
			mdlvie.setViewName("login");
			mdlvie.addObject("userbean",userbean);
			mdlvie.addObject("requestbean",requestbean);
			return mdlvie;
		}
		else
		{
		
		
		
			System.out.println("In Get method of ApplyControl");
			@SuppressWarnings("unused")
			int getspid=0;
			int reqid = 0;
			String reqname=null;
			
			String uname=session.getAttribute("username").toString().trim();
			
			System.out.println("Session username:"+uname);
			Session session1=(Session)SessionUtility.GetSessionConnection();
			  Criteria criteria = session1.createCriteria(ServiceRequester.class);
			   
              criteria.add(Restrictions.eq("rq_username",uname));
              ServiceRequester requester = (ServiceRequester) criteria.uniqueResult();
              
              if (requester!=null) 
              {
            	  System.out.println("Requestid Found");
            	  reqid=requester.getRq_id();
            	  reqname=requester.getRq_name();
                  System.out.println(requester.getRq_id() + " - " + requester.getRq_name());
  
              }
			
			String reqjobname=null;
			String cname=null;
			
			System.out.println("name:"+requestbean.getRq_name());
			ModelAndView mdlv=new ModelAndView();
			System.out.println("Reqid:"+reqid);
			System.out.println("Job name:"+jobbean.getCheckjobs());
			System.out.println(jobbean.getProduct());
			for (String s  : jobbean.getProduct()) {
				//session.setAttribute(s.toString().trim(),s.toString().trim());
				System.out.println("checked job name:"+s);
				reqjobname=s;
				
				}
			String hql = "FROM job.Jobs where job_name = :jobname";
			
			Query query = session1.createQuery(hql);
			query.setString("jobname",reqjobname);
			
			ServiceProvider sobj=null;

			
			
			@SuppressWarnings("unchecked")
			List<Jobs> results = query.list();
			System.out.println(results);
			Iterator<Jobs> it=results.iterator();
			Iterator<Jobs> it1=results.iterator();
			Iterator<Jobs> it2=results.iterator();
			
			if (it.hasNext())
			{
				getspid=it.next().getSpobj().getSp_id();
			}
			if(it1.hasNext())
			{
				cname=it1.next().getSpobj().getSp_name();
			}
			
			System.out.println("cname:"+cname);
		
			if(it2.hasNext())
			{
				sobj=it2.next().getSpobj();
			}
			
			System.out.println("sobj:"+sobj);
			System.out.println("Am here at last");
			System.out.println("updated");
			Applied appl=new Applied();
			appl.setApplied(reqid);
			appl.setRequestername(reqname);
			appl.setJobname(reqjobname);
			appl.setCname(cname);
			appl.setAppobj(sobj);
			session1.save(appl);
			SessionUtility.closeSession(null);
			
			mdlv.setViewName("inindex");
			mdlv.addObject("jobbean",jobbean);
			mdlv.addObject("providerbean",providerbean);
			
			//SessionUtility.closeSession(null);
			return mdlv;
		
		}
	}
	@RequestMapping(method=RequestMethod.POST)
	public ModelAndView nextposition(Jobs jobbean)
	{
		System.out.println("In post method of Appply control");
		System.out.println("Am here");
		ModelAndView md=new ModelAndView();
		md.addObject("jobbean",jobbean);
		md.setViewName("index");
		return md;
		
	}
	
	
}
