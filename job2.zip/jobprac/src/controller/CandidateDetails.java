package controller;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import database.SessionUtility;
import job.RequestJobs;

import job.ServiceRequester;



@Controller
@RequestMapping("candidatedetails")
public class CandidateDetails 
{

	@Autowired
	ServiceRequester requestbean;


	public ServiceRequester getRequestbean() {
		return requestbean;
	}

	public void setRequestbean(ServiceRequester requestbean) {
		this.requestbean = requestbean;
	}
	
	
	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView getMethod(ServiceRequester requestbean)
	{
		System.out.println("In get Method of CandidateDetails");
		ModelAndView mdlv=new ModelAndView();
		 int reqid=0;
		 System.out.println(reqid);
		  for (int i  : requestbean.getCheck()) {
				//session.setAttribute(s.toString().trim(),s.toString().trim());
				System.out.println(i);
				reqid=i;
				
				}		
		  System.out.println("RequesterId:"+reqid);
			
			Session session1=(Session)SessionUtility.GetSessionConnection();
		
			String hql = "FROM job.RequestJobs where rqobj = :rqobj";
			Query query = session1.createQuery(hql);
		
			query.setInteger("rqobj",reqid);
			@SuppressWarnings("unchecked")
			List<RequestJobs> results = query.list();
			System.out.println(results);
			Iterator<RequestJobs> it=results.iterator();
			System.out.println("List executed");
			while (it.hasNext())
			{
				System.out.println("Job Name"+it.next().getJob_name());
				
				
				//updating the applyrequest to reqid value
			}	
			
			mdlv.addObject("candidates",results);
			mdlv.setViewName("candidatedetails");
			mdlv.addObject("requestbean", requestbean);
		
		
		
		
		return mdlv;
	}
	
	
	
	
}
